package com.klef.jfsd.exam;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import java.util.Scanner;

public class ClientDemo {

    public static void main(String[] args) {
        Configuration cfg = new Configuration();
        cfg.configure("hibernate.cfg.xml");
        cfg.addAnnotatedClass(Department.class);
        SessionFactory factory = cfg.buildSessionFactory();

        Scanner scanner = new Scanner(System.in);

        try (Session session = factory.openSession()) {
            Transaction transaction = session.beginTransaction();

            // Insert Operation
            System.out.println("Enter Department details for insertion:");
            Department department = new Department();
            System.out.print("Name: ");
            department.setName(scanner.nextLine());
            System.out.print("Location: ");
            department.setLocation(scanner.nextLine());
            System.out.print("HoD Name: ");
            department.setHodName(scanner.nextLine());

            session.save(department);
            System.out.println("Department record inserted successfully!");

            transaction.commit();
        }

        try (Session session = factory.openSession()) {
            Transaction transaction = session.beginTransaction();

            // Delete Operation using HQL
            System.out.print("Enter the Department ID to delete: ");
            int departmentId = scanner.nextInt();

            String hql = "DELETE FROM Department WHERE departmentId = ?1";
            int result = session.createQuery(hql)
                                .setParameter(1, departmentId)
                                .executeUpdate();

            if (result > 0) {
                System.out.println("Department record deleted successfully!");
            } else {
                System.out.println("No record found with the given Department ID.");
            }

            transaction.commit();
        }

        factory.close();
        scanner.close();
    }
}
